package MineSweeper;
public class Main {
	public static void main(String[] args) {
		new Menu();
	}//해당 프로젝트는 지금까지 학습한 내용 대부분 응용하여 쓰는 것을 목표로 제작 while,for 무한루프 응용 등
}//단점: 아직 비동기 통신을 배우지 않아 프로그램 실행중에 정보갱신을 하지 못함.
//실시간으로는 불러오지는 못하는 단점을 지님
