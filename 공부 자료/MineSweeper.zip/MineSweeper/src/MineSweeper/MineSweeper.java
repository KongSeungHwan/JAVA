package MineSweeper;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MineSweeper {
	 Map<Integer, List<Integer>> mineList;
	public static void main(String[] args) {
			MineSweeper m = new MineSweeper(25);//고객 등급에 따라 어차피 x by x는 받을거기 때문에 임의로 10으로 함
			System.out.printf("좌표 값을 입력하십시오.(가로▷,세로▽) ex) x,y(순서쌍 단 1~%d까지(1부터 시작)) \n",m.mineList.size());
			System.out.printf("%d by %d\n",m.mineList.get(1).size(),m.mineList.size()); //일단 모든 원소가 동일한 크기의 리스트기에 아무 원소의 사이즈를 가져옴
			m.panView(m.mineList);
//		try(BufferedReader n = new BufferedReader(new InputStreamReader(System.in));
//				) {
//				for(;true;){
//					
//					String pair = n.readLine(); //문자열로 받은 후
//					
//				}
//		} catch (NumberFormatException | IOException e) {
//			System.out.println("유효하지 않은 값을 입력하셨습니다.");
//		}catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println("순서쌍이 범위 바깥 값을 입력하셨습니다.");
//		}
	}
	MineSweeper(int num){
		mineList=createMine(num);
	}

	Map<Integer, List<Integer>> createMine(int num){
		return IntStream.rangeClosed(1, num)
		.boxed()
		.collect(Collectors.toMap(s->s,s->new Random().ints(1,3).boxed().limit(num).collect(Collectors.toList())));
	} //Map의 키값은 row로 구현, 또한 안의 원소는 list며 원소는 1(폭탄),0(일반 땅)을 의미
	
	<T> void panView(Map<Integer, List<T>> l) {
		Iterator<Entry<Integer, List<T>>> it= l.entrySet().iterator();
		while(it.hasNext()) {
			Entry<Integer, List<T>> token= it.next();
			token.getValue().stream().forEach(s->System.out.printf(String.format("%s ",s)));
			System.out.println();
		}
	}//지뢰찾기 판을 줄에 맞도록 출력하는 메소드
	//원소들이 Integer이거나 String일 수 있어 제네릭 메소드 정의!
	
	Map<Integer, List<String>> hideMine(int size){
		return IntStream.rangeClosed(1, size)
				.boxed()
				.collect(Collectors.toMap(s->s,s-> Stream.generate(()-> "*")
				.limit(size)
				.collect(Collectors.toList())));
	}//임의의 땅을 "*"으로 표현하고 이제 1(맨땅)인지 2(폭탄)인지 맞추는 게임
//	Integer detectMine(String pair){
//		String[] p= pair.split(",");
//		int x = Integer.parseInt(p[0])-1, y=Integer.parseInt(p[1]);
//		return mineList.put()
//
//	}
}
