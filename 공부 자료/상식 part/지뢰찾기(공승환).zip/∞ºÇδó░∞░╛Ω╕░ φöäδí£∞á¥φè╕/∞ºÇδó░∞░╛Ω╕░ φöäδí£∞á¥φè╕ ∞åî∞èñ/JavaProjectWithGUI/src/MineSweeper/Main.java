package MineSweeper;
public class Main {
	public static void main(String[] args) {
		new MainMenuPage().frm.setVisible(true);
	}
}