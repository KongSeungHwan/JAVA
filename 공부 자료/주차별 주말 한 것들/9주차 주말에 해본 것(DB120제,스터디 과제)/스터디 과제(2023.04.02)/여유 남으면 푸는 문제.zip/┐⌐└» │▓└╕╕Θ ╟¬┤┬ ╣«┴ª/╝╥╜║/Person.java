package Prac5;

public class Person {
	String name;
	int age;

	Person(String n,int a){
		name=n;
		age=a;
	}
}
